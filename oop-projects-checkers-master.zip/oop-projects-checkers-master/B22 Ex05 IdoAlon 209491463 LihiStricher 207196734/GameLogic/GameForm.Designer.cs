﻿//namespace GameLogic
//{
//    partial class GameForm
//    {
//        /// <summary>
//        /// Required designer variable.
//        /// </summary>
//        private System.ComponentModel.IContainer components = null;

//        /// <summary>
//        /// Clean up any resources being used.
//        /// </summary>
//        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
//        protected override void Dispose(bool disposing)
//        {
//            if (disposing && (components != null))
//            {
//                components.Dispose();
//            }
//            base.Dispose(disposing);
//        }

//        #region Windows Form Designer generated code

//        /// <summary>
//        /// Required method for Designer support - do not modify
//        /// the contents of this method with the code editor.
//        /// </summary>
//        private void InitializeComponent()
//        {
//            this.Player1Name = new System.Windows.Forms.Label();
//            this.Player2Name = new System.Windows.Forms.Label();
//            this.SuspendLayout();
//            // 
//            // Player1Name
//            // 
//            this.Player1Name.AutoSize = true;
//            this.Player1Name.Location = new System.Drawing.Point(67, 34);
//            this.Player1Name.Name = "Player1Name";
//            this.Player1Name.Size = new System.Drawing.Size(51, 20);
//            this.Player1Name.TabIndex = 0;
//            this.Player1Name.Text = "label1";
//            // 
//            // Player2Name
//            // 
//            this.Player2Name.AutoSize = true;
//            this.Player2Name.Location = new System.Drawing.Point(354, 43);
//            this.Player2Name.Name = "Player2Name";
//            this.Player2Name.Size = new System.Drawing.Size(51, 20);
//            this.Player2Name.TabIndex = 1;
//            this.Player2Name.Text = "label1";
//            // 
//            // GameForm
//            // 
//            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
//            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
//            this.ClientSize = new System.Drawing.Size(495, 450);
//            this.Controls.Add(this.Player2Name);
//            this.Controls.Add(this.Player1Name);
//            this.Name = "GameForm";
//            this.Text = "GameForm";
//            this.Load += new System.EventHandler(this.GameForm_Load);
//            this.ResumeLayout(false);
//            this.PerformLayout();

//        }

//        #endregion

//        private System.Windows.Forms.Label Player1Name;
//        private System.Windows.Forms.Label Player2Name;
//    }
//}